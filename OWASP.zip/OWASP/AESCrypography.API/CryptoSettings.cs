﻿namespace AESCrypography.API
{
    public class CryptoSettings
    {
        public string Key { get; set; }
        public string IV { get; set; }
    }
}
