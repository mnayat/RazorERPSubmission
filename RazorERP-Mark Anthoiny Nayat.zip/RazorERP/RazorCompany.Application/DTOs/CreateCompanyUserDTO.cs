﻿using RazorCompany.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RazorCompany.Application.DTOs
{
    public class CreateCompanyUserDTO
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public int CompanyID { get; set; }

        public UserRole UserRole { get; set; }
    }
}
