﻿using RazorCompany.Domain.Enums;


namespace RazorCompany.Application.DTOs
{
    public class UpdateCompanyUserDTO
    {
        public int RazorERPUserID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public int CompanyID { get; set; }
        public UserRole UserRole { get; set; }
    }
}
