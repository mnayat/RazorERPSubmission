﻿using RazorCompany.Application.Interfaces.JWTService;
using RazorCompany.Application.Interfaces.MediatrMessaging;
using RazorCompany.Application.Interfaces.Persistence;
using RazorCompany.Application.Interfaces.Shared;
using RazorCompany.Application.Shared;
using RazorCompany.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RazorCompany.Application.Features.Authentication
{
    public class AuthenticationQueryHandler : IQueryHandler<LoginQuery, Result<AuthenticationTokenResult>>
    {
        private readonly IJWTAuthService _jWTAuthService;

        private readonly IUnitofWork _unitofWork;
        IPasswordHashSaltGenerator _passwordHashSaltGenerator;

        public AuthenticationQueryHandler(IJWTAuthService jWTAuthService, IUnitofWork unitofWork, IPasswordHashSaltGenerator passwordHashSaltGenerator)
        {
            _unitofWork = unitofWork;
            _jWTAuthService = jWTAuthService;
            _passwordHashSaltGenerator = passwordHashSaltGenerator;

        }
        public async Task<Result<AuthenticationTokenResult>> Handle(LoginQuery request, CancellationToken cancellationToken)
        {
            var user = await _unitofWork.GetRepository<RazorCompanyUser>()
                .ApplyPredicate(u => u.UserName == request.Username);

            if (!user.Any()) {
                return await Result<AuthenticationTokenResult>.FailureAsync("Authentication Error: username and password unauthorized");
              
            }

            var storedHash = user.FirstOrDefault()!.PasswordHash;
            var storedsalt = user.FirstOrDefault()!.PasswordSalt;
            ;
            var isVerify = _passwordHashSaltGenerator.VerifyPassword( request.Password, storedHash, storedsalt);
            if (isVerify)
            {
                var token = _jWTAuthService.GenerateUserJwtToken(request.Username ,user.FirstOrDefault()!.UserRole);
                var authenticationResult = new AuthenticationTokenResult(request.Username, token);
                return await Result<AuthenticationTokenResult>.SuccessAsync(authenticationResult, "Token successfully generated");
            }
            return await Result<AuthenticationTokenResult>.FailureAsync("Authentication Error: username and password unauthorized");
        }
    }
}
