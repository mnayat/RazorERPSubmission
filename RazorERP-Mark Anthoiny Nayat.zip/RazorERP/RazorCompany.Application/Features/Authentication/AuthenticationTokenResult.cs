﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RazorCompany.Application.Features.Authentication
{
    public record AuthenticationTokenResult(string UserName, string Token);
}
