﻿using RazorCompany.Application.Interfaces.MediatrMessaging;
using RazorCompany.Application.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RazorCompany.Application.Features.Authentication
{
    public record LoginQuery(string Username, string Password)
         : IQuery<Result<AuthenticationTokenResult>>;
}
