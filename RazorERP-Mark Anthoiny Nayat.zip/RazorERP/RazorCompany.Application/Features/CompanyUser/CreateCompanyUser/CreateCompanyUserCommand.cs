﻿using RazorCompany.Application.DTOs;
using RazorCompany.Application.Interfaces.MediatrMessaging;
using RazorCompany.Application.Shared;

namespace RazorCompany.Application.Features.CompanyUser.CreateCompanyUser
{
    public record CreateCompanyUserCommand(CreateCompanyUserDTO userDTO)
        : ICommand<Result<string>>;
}