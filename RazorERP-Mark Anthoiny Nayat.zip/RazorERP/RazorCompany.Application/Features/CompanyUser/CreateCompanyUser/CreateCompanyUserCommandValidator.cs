﻿using FluentValidation;

namespace RazorCompany.Application.Features.CompanyUser.CreateCompanyUser
{
    public class CreateCompanyUserCommandValidator : AbstractValidator<CreateCompanyUserCommand>
    {
        public CreateCompanyUserCommandValidator()
        {
            RuleFor(cuc => cuc.userDTO.UserName)
               .NotEmpty()
               .WithMessage("UserName is required");

            RuleFor(cuc => cuc.userDTO.Password)
               .NotEmpty()
               .WithMessage("Password is required");

            RuleFor(cuc => cuc.userDTO.CompanyID)
              .NotEmpty()
              .WithMessage("CompanyID is required");
        }
    }
}