﻿using Mapster;
using Microsoft.AspNetCore.Http;
using RazorCompany.Application.DTOs;
using RazorCompany.Application.Interfaces.MediatrMessaging;
using RazorCompany.Application.Interfaces.Persistence;
using RazorCompany.Application.Interfaces.Shared;
using RazorCompany.Application.Shared;
using RazorCompany.Application.Shared.Extensions;
using RazorCompany.Domain.Entities;
using System.Net;

namespace RazorCompany.Application.Features.CompanyUser.CreateCompanyUser
{
    public class CreateCompanyUserHandler :
        ICommandHandler<CreateCompanyUserCommand, Result<string>>
    {
        private readonly IUnitofWork _unitofWork;
        private readonly IPasswordHashSaltGenerator _passwordHashSaltGenerator;
        private readonly string _userName; 

        public CreateCompanyUserHandler(
            IUnitofWork unitofWork,
            IHttpContextAccessor contextAccessor, 
            IPasswordHashSaltGenerator passwordHashSaltGenerator
            )
        {
            _unitofWork = unitofWork;
            _passwordHashSaltGenerator = passwordHashSaltGenerator;
            _userName = (string)contextAccessor.HttpContext?.Items["UserName"]!;
        }

        public async Task<Result<string>> Handle(CreateCompanyUserCommand request, CancellationToken cancellationToken)
        {
            // mapper
            var companyUserDTO = request.userDTO.Adapt<CreateCompanyUserDTO>();
            var entityCompanyUser = companyUserDTO.Adapt<RazorCompanyUser>();


            // generate hash and salt password
            entityCompanyUser.PasswordHash = _passwordHashSaltGenerator
               .HashPasword(companyUserDTO.Password, out var salt);

            entityCompanyUser.PasswordSalt = salt;

            entityCompanyUser.SetAuditFieldsOnCreate(_userName);

            var companyUserExists = await _unitofWork.GetRepository<RazorCompanyUser>()
               .AnyAsync(cu => cu.UserName == entityCompanyUser.UserName);

            // check if the user exist
            if (companyUserExists)
            {
                return await Result<string>
                    .FailureAsync((int)HttpStatusCode.Conflict, "Company user is exisiting.");
            }

            // save new CompanyUser

            await _unitofWork.GetRepository<RazorCompanyUser>().AddAsync(entityCompanyUser);
            var isNewCompanyUserCreated = _unitofWork.SaveChanges(cancellationToken);

            if (!isNewCompanyUserCreated.Result)
            {
                return await Result<string>
                    .FailureAsync("Unable to create new company user. ");
            }

            return await Result<string>
                .SuccessAsync(entityCompanyUser.UserName,
                "New company user successfully created.");
        }
    }
}