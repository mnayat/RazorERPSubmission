﻿using FluentValidation;

namespace RazorCompany.Application.Features.CompanyUser.DeleteCompanyUser
{
    public class DeleteCompanyUserValidator : AbstractValidator<DeleteCompanyUserCommand>
    {
        public DeleteCompanyUserValidator()
        {
            RuleFor(cuc => cuc.UserID)
              .NotEmpty()
              .WithMessage("UserID is required");
        }
    }
}