﻿using Mapster;
using RazorCompany.Application.DTOs;
using RazorCompany.Application.Interfaces.MediatrMessaging;
using RazorCompany.Application.Interfaces.Persistence;
using RazorCompany.Application.Shared;
using RazorCompany.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RazorCompany.Application.Features.CompanyUser.PopulateCompanyUser
{
    public class PopulateCompanyUserQueryHandler : IQueryHandler<PopulateCompanyUserQuery, Result<List<SearchCompanyUserDTOs>>>
    {
        private readonly IUnitofWork _unitofWork;
        public PopulateCompanyUserQueryHandler(IUnitofWork unitofWork)
        {

            _unitofWork = unitofWork;
        }
        public async Task<Result<List<SearchCompanyUserDTOs>>> Handle(PopulateCompanyUserQuery request, CancellationToken cancellationToken)
        {
            var result = await _unitofWork.GetRepository<RazorCompanyUser>().GetAllAsync();

            var maptoDTO = result?.Adapt<List<SearchCompanyUserDTOs>>();
            if(result != null)
            {
               return await Result<List<SearchCompanyUserDTOs>>.SuccessAsync(maptoDTO!);
            }
            return await Result<List<SearchCompanyUserDTOs>>.FailureAsync("error populating the company user record");
        }
    }
}
