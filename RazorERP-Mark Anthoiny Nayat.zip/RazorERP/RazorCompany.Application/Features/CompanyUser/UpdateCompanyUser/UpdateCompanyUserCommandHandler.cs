﻿using Mapster;
using Microsoft.AspNetCore.Http;
using RazorCompany.Application.DTOs;
using RazorCompany.Application.Features.CompanyUser.CreateCompanyUser;
using RazorCompany.Application.Interfaces.MediatrMessaging;
using RazorCompany.Application.Interfaces.Persistence;
using RazorCompany.Application.Interfaces.Shared;
using RazorCompany.Application.Shared;
using RazorCompany.Application.Shared.Extensions;
using RazorCompany.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RazorCompany.Application.Features.CompanyUser.UpdateCompanyUser
{
    public class UpdateCompanyUserCommandHandler : ICommandHandler<UpdateCompanyUserCommand, Result<string>>
    {
        private readonly IUnitofWork _unitofWork;
        private readonly IPasswordHashSaltGenerator _passwordHashSaltGenerator;
        private readonly string _userName;

        public UpdateCompanyUserCommandHandler(IUnitofWork unitofWork,
            IHttpContextAccessor contextAccessor,
            IPasswordHashSaltGenerator passwordHashSaltGenerator
            )
        {
            _unitofWork = unitofWork;
            _passwordHashSaltGenerator = passwordHashSaltGenerator;
            _userName = (string)contextAccessor.HttpContext?.Items["UserName"]!;
        }

        public async Task<Result<string>> Handle(UpdateCompanyUserCommand request, CancellationToken cancellationToken)
        {
            var companyUserDTO = request.userDTO.Adapt<UpdateCompanyUserDTO>();
            var entityCompanyUser = companyUserDTO.Adapt<RazorCompanyUser>();

            var companyUserExists = await _unitofWork.GetRepository<RazorCompanyUser>()
             .AnyAsync(cu => cu.RazorERPUserID == entityCompanyUser.RazorERPUserID);

            // check if the user exist
            if (!companyUserExists)
            {
              
                return await Result<string>
                    .FailureAsync((int)HttpStatusCode.Conflict, "Company user is not exisiting.");
            }

            // update CompanyUser
            // generate hash and salt password
            entityCompanyUser.PasswordHash = _passwordHashSaltGenerator
               .HashPasword(companyUserDTO.Password, out var salt);
            entityCompanyUser.PasswordSalt = salt!;

            entityCompanyUser.SetAuditFieldsOnUpdate(_userName);

            await _unitofWork.GetRepository<RazorCompanyUser>().UpdateAsync(entityCompanyUser.RazorERPUserID, entityCompanyUser);
           var isUpdated =  await _unitofWork.SaveChanges(cancellationToken);
            if (!isUpdated)
            {
                return await Result<string>
                .FailureAsync("Unable to update company user. ");

            }
            return await Result<string>
               .SuccessAsync(entityCompanyUser.UserName,
               "Company User is now updated.");
        }
    }
}