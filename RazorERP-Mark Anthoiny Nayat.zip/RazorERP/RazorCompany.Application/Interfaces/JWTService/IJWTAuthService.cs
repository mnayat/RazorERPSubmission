﻿using RazorCompany.Domain.Enums;

namespace RazorCompany.Application.Interfaces.JWTService
{
    public interface IJWTAuthService
    {
        string GenerateUserJwtToken(string username, UserRole role);
    }
}