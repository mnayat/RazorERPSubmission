﻿using MediatR;

namespace RazorCompany.Application.Interfaces.MediatrMessaging
{
    public interface ICommand<out TResponse> : IRequest<TResponse>
    {
    }
}