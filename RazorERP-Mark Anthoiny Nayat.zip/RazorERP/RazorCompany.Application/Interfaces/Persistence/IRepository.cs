﻿using RazorCompany.Domain.Entities.Common;
using System.Linq.Expressions;

namespace RazorCompany.Application.Interfaces.Persistence
{
    public interface IRepository<T> where T : BaseAuditableEntity
    {
        Task<T> GetByIdAsync(int id);

        Task<T> AddAsync(T entity);

        Task UpdateAsync(int id, T entity);

        Task DeleteAsync(T entity);

        Task<IQueryable<T>> GetAllAsync();
        Task<bool> AnyAsync(Expression<Func<T, bool>> predicate);
        Task<IQueryable<T>> ApplyPredicate(Expression<Func<T, bool>> predicate);
    }
}