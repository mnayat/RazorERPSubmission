﻿using RazorCompany.Domain.Entities.Common;

namespace RazorCompany.Application.Interfaces.Persistence
{
    public interface IUnitofWork
    {
        IRepository<T> GetRepository<T>() where T : BaseAuditableEntity;

        Task<bool> SaveChanges(CancellationToken cancellationToken);
    }
}