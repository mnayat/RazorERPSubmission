﻿namespace RazorCompany.Domain.Entities.Common
{
    public class BaseAuditableEntity
    {
        public string? CreatedBy { get; set; }
        public DateTimeOffset? CreatedDate { get; set; }
        public string? ModifiedBy { get; set; }
        public DateTimeOffset? ModifiedDate { get; set; }
    }
}