﻿using RazorCompany.Domain.Entities.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RazorCompany.Domain.Entities
{
    public class Company : BaseAuditableEntity
    {
        public int CompanyID { get; set; }
        public string CompanyName { get; set; }
        public virtual  ICollection<RazorCompanyUser> RazorERPUsers { get; set; }
    }
}