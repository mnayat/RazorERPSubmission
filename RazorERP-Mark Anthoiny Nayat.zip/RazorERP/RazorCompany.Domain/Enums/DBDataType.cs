﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RazorCompany.Domain.Enums
{
    public enum DBDataType
    {
        NVARCHAR,
        VARCHAR,
        DATETIMEOFFSET,
        DATE
    }
}
