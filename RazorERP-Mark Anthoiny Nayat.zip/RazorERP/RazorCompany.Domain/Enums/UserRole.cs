﻿namespace RazorCompany.Domain.Enums
{
    public enum UserRole
    {
        Admin = 1,
        FlatUsers = 2
    }
}