﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace RazorCompany.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "RazorERP");

            migrationBuilder.CreateTable(
                name: "Company",
                schema: "RazorERP",
                columns: table => new
                {
                    CompanyID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CompanyName = table.Column<string>(type: "NVARCHAR(200)", maxLength: 200, nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    CreatedDate = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedDate = table.Column<DateTimeOffset>(type: "datetimeoffset", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Company", x => x.CompanyID);
                });

            migrationBuilder.CreateTable(
                name: "RazorCompanyUser",
                schema: "RazorERP",
                columns: table => new
                {
                    RazorERPUserID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserName = table.Column<string>(type: "NVARCHAR(200)", maxLength: 200, nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PasswordSalt = table.Column<byte[]>(type: "varbinary(max)", nullable: false),
                    CompanyID = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    CreatedDate = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedDate = table.Column<DateTimeOffset>(type: "datetimeoffset", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RazorCompanyUser", x => x.RazorERPUserID);
                    table.ForeignKey(
                        name: "FK_RazorCompanyUser_Company_CompanyID",
                        column: x => x.CompanyID,
                        principalSchema: "RazorERP",
                        principalTable: "Company",
                        principalColumn: "CompanyID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                schema: "RazorERP",
                table: "Company",
                columns: new[] { "CompanyID", "CompanyName", "CreatedBy", "CreatedDate", "ModifiedBy", "ModifiedDate" },
                values: new object[,]
                {
                    { 1, "Company 1", "SytemAdmin", new DateTimeOffset(new DateTime(2024, 8, 13, 11, 23, 48, 645, DateTimeKind.Unspecified).AddTicks(2998), new TimeSpan(0, 0, 0, 0, 0)), null, null },
                    { 2, "Company 2", "SytemAdmin", new DateTimeOffset(new DateTime(2024, 8, 13, 11, 23, 48, 645, DateTimeKind.Unspecified).AddTicks(3025), new TimeSpan(0, 0, 0, 0, 0)), null, null },
                    { 3, "Company 3", "SytemAdmin", new DateTimeOffset(new DateTime(2024, 8, 13, 11, 23, 48, 645, DateTimeKind.Unspecified).AddTicks(3026), new TimeSpan(0, 0, 0, 0, 0)), null, null },
                    { 4, "Company 4", "SytemAdmin", new DateTimeOffset(new DateTime(2024, 8, 13, 11, 23, 48, 645, DateTimeKind.Unspecified).AddTicks(3027), new TimeSpan(0, 0, 0, 0, 0)), null, null },
                    { 5, "Company 5", "SytemAdmin", new DateTimeOffset(new DateTime(2024, 8, 13, 11, 23, 48, 645, DateTimeKind.Unspecified).AddTicks(3028), new TimeSpan(0, 0, 0, 0, 0)), null, null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_RazorCompanyUser_CompanyID",
                schema: "RazorERP",
                table: "RazorCompanyUser",
                column: "CompanyID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "RazorCompanyUser",
                schema: "RazorERP");

            migrationBuilder.DropTable(
                name: "Company",
                schema: "RazorERP");
        }
    }
}
