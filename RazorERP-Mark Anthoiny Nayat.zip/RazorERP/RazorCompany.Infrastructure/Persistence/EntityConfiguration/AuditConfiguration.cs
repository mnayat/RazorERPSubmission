﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RazorCompany.Domain.Entities.Common;

namespace RazorCompany.Infrastructure.Persistence.EntityConfiguration
{
    public static class AuditConfiguration
    {
        public static void ConfigureAuditFields<T>(EntityTypeBuilder<T> builder)
            where T : BaseAuditableEntity
        {
            builder.Property(e => e.CreatedDate);

            builder.Property(e => e.CreatedBy)
                .HasMaxLength(255);

            builder.Property(e => e.ModifiedBy);

            builder.Property(e => e.ModifiedDate)
                .HasMaxLength(255);
        }
    }
}