﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RazorCompany.Domain.Entities;
using RazorCompany.Domain.Enums;

namespace RazorCompany.Infrastructure.Persistence.EntityConfiguration
{
    public class CompanyConfiguration : IEntityTypeConfiguration<Company>
    {
        public void Configure(EntityTypeBuilder<Company> builder)
        {
            AuditConfiguration.ConfigureAuditFields(builder);

            builder.ToTable(nameof(Company), "RazorERP");


            builder.HasKey(c => c.CompanyID)
              .HasAnnotation("SqlServer:Identity", "1, 1");


            builder.Property(c => c.CompanyName)
           .HasMaxLength(200)
           .HasColumnType(DBDataType.NVARCHAR.ToString());

            builder.HasMany(c => c.RazorERPUsers)
                .WithOne(u => u.Company)
                .HasForeignKey(u => u.CompanyID);


            builder.HasData(

                new Company { 
                    CompanyID = 1,
                    CompanyName ="Company 1",
                    CreatedBy = "SytemAdmin",
                    CreatedDate = DateTime.UtcNow,
                
                },
                 new Company
                 {
                     CompanyID = 2,
                     CompanyName = "Company 2",
                     CreatedBy = "SytemAdmin",
                     CreatedDate = DateTime.UtcNow,

                 },
                  new Company
                  {
                      CompanyID = 3,
                      CompanyName = "Company 3",
                      CreatedBy = "SytemAdmin",
                      CreatedDate = DateTime.UtcNow,

                  },
                   new Company
                   {
                       CompanyID = 4,
                       CompanyName = "Company 4",
                       CreatedBy = "SytemAdmin",
                       CreatedDate = DateTime.UtcNow,

                   },
                    new Company
                    {
                        CompanyID = 5,
                        CompanyName = "Company 5",
                        CreatedBy = "SytemAdmin",
                        CreatedDate = DateTime.UtcNow,

                    }

                );

        }
    }
}