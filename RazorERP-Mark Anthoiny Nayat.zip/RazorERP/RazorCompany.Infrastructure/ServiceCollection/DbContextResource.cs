﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RazorCompany.Application.Configurations;

namespace RazorCompany.Infrastructure.ServiceCollection
{
    public static class DbContextResource
    {
        public static void AddDatabaseContext(this IServiceCollection services, IConfiguration configuration)
        {
            var appSettings = configuration.GetRequiredSection("AppSettings").Get<AppSettings>();
            var connectionString = appSettings?.ConnectionString;

            services.AddDbContext<ApplicationDBContext>(options =>
                options.UseLazyLoadingProxies().
                UseSqlServer(connectionString,
                builder =>
                builder.MigrationsAssembly(typeof(ApplicationDBContext).Assembly.FullName))
            );
        }
    }
}