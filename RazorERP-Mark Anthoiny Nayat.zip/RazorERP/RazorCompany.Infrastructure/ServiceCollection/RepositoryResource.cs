﻿using Microsoft.Extensions.DependencyInjection;
using RazorCompany.Application.Interfaces.Persistence;
using RazorCompany.Infrastructure.Persistence.Repositories;

namespace RazorCompany.Infrastructure.ServiceCollection
{
    public static class RepositoryResource
    {
        public static void AddRepositories(this IServiceCollection services)
        {
            services
                .AddScoped(typeof(IUnitofWork), typeof(UnitofWork))
                .AddScoped(typeof(IRepository<>), typeof(Repository<>));
        }
    }
}