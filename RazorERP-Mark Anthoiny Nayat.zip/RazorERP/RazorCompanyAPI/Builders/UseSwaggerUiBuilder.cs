﻿using Asp.Versioning.ApiExplorer;

namespace RazorCompanyAPI.Builders
{
    public static class UseSwaggerUiBuilder
    {
        public static IApplicationBuilder UseConfigureSwaggerUI(this IApplicationBuilder app)
        {
            var apiVersionDescriptionProvider = 
                app.ApplicationServices.GetRequiredService<IApiVersionDescriptionProvider>();
            app.UseSwaggerUI(options =>
            {
                foreach (var description in apiVersionDescriptionProvider.ApiVersionDescriptions)
                {
                    options.SwaggerEndpoint($"/swagger/{description.GroupName}/swagger.json",
                       $"RazorErp API {description.GroupName.ToUpperInvariant()}");
                }
            });
            return app;
        }
    }
}
