﻿using System.Security.Claims;

namespace RazorCompanyAPI.Middleware
{/// <summary>
/// /
/// </summary>
    public class ThrottlingMiddleware
    {
        private static readonly Dictionary<string, (DateTime Timestamp, int Count)> Requests = new();
        private readonly RequestDelegate _next;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="next"></param>
        public ThrottlingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var userId = context.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

            if (userId != null)
            {
                var currentTime = DateTime.UtcNow;
                if (Requests.ContainsKey(userId))
                {
                    var (timestamp, count) = Requests[userId];
                    if (currentTime - timestamp < TimeSpan.FromMinutes(1))
                    {
                        if (count >= 1)
                        {
                            context.Response.StatusCode = StatusCodes.Status429TooManyRequests;
                            await context.Response.WriteAsync("Too many requests. Please try again later.");
                            return;
                        }
                        Requests[userId] = (timestamp, count + 1);
                    }
                    else
                    {
                        Requests[userId] = (currentTime, 1);
                    }
                }
                else
                {
                    Requests[userId] = (currentTime, 1);
                }
            }

            await _next(context);
        }
    }

}
