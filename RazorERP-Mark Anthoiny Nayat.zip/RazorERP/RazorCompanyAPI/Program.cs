using RazorCompany.Application;
using RazorCompany.Infrastructure;
using RazorCompanyAPI.Builders;
using RazorCompanyAPI.Middleware;
using RazorCompanyAPI.SwaggerUIOptions;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//Swagger UI custom configurations
builder.Services.AddApplicationVersioning();
builder.Services.ConfigureOptions<ConfigureSwaggerOptions>();



// Registering Service Collections
builder.Services.AddHttpContextAccessor();

builder.Services
    .AddApplication()
    .AddInfrastructure(builder.Configuration);


var app = builder.Build();


// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseConfigureSwaggerUI();
}

.// need to fix why the userid cannot retrieve from context
//app.UseMiddleware<ThrottlingMiddleware>();

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
