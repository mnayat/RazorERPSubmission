﻿using RazorCompany.Domain.Exceptions;

namespace RazorCompany.Application.Exceptions
{
    public class ValidationException : AppException
    {
        public ValidationException(IReadOnlyDictionary<string, string[]> errorsDictionary)
            : base("Validation Failure", "One or more validation errors occurred")
        {
            ErrorsDictionary = errorsDictionary;
        }

        public IReadOnlyDictionary<string, string[]> ErrorsDictionary { get; }
    }
}