﻿using RazorCompany.Application.Interfaces.MediatrMessaging;
using RazorCompany.Application.Interfaces.Persistence;
using RazorCompany.Application.Shared;
using RazorCompany.Domain.Entities;

namespace RazorCompany.Application.Features.CompanyUser.DeleteCompanyUser
{
    public class DeleteCompanyUserHandler : ICommandHandler<DeleteCompanyUserCommand, Result<string>>
    {
        private readonly IUnitofWork _unitofWork;

        public DeleteCompanyUserHandler(IUnitofWork unitofWork)
        {
            _unitofWork = unitofWork;
        }

        public async Task<Result<string>> Handle(DeleteCompanyUserCommand request, CancellationToken cancellationToken)
        {
            var companyUser = await _unitofWork.GetRepository<RazorCompanyUser>()
                .GetByIdAsync(request.UserID);

            if (companyUser == null)
            {
                return await Result<string>
                .FailureAsync("Company user is not found. ");
            }
            await _unitofWork.GetRepository<RazorCompanyUser>()
                 .DeleteAsync(companyUser);
            var isdeleted = _unitofWork.SaveChanges(cancellationToken);

            if (!isdeleted.Result)
            {
                return await Result<string>
              .FailureAsync("Unable to delete company user. ");
            }
            return await Result<string>
                 .SuccessAsync(request.UserID,
                 "Company User is  successfully deleted.");
        }
    }
}