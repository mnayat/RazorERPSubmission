﻿using RazorCompany.Application.DTOs;
using RazorCompany.Application.Interfaces.MediatrMessaging;
using RazorCompany.Application.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RazorCompany.Application.Features.CompanyUser.PopulateCompanyUser
{
    public record PopulateCompanyUserQuery() : IQuery<Result<List<SearchCompanyUserDTOs>>>;
   
}
