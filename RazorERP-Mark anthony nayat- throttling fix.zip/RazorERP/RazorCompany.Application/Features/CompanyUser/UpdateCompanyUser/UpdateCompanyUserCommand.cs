﻿using RazorCompany.Application.DTOs;
using RazorCompany.Application.Interfaces.MediatrMessaging;
using RazorCompany.Application.Shared;

namespace RazorCompany.Application.Features.CompanyUser.UpdateCompanyUser
{
    public record UpdateCompanyUserCommand(UpdateCompanyUserDTO userDTO)
    : ICommand<Result<string>>;
}