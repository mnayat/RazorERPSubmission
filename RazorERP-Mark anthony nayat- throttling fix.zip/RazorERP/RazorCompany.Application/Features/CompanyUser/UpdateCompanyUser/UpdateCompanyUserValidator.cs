﻿using FluentValidation;

namespace RazorCompany.Application.Features.CompanyUser.UpdateCompanyUser
{
    public class UpdateCompanyUserValidator : AbstractValidator<UpdateCompanyUserCommand>
    {
        public UpdateCompanyUserValidator()
        {
            RuleFor(cuc => cuc.userDTO.UserName)
               .NotEmpty()
               .WithMessage("UserName is required");

            RuleFor(cuc => cuc.userDTO.Password)
               .NotEmpty()
               .WithMessage("Password is required");

            RuleFor(cuc => cuc.userDTO.CompanyID)
              .NotEmpty()
              .WithMessage("CompanyID is required");
        }
    }
}