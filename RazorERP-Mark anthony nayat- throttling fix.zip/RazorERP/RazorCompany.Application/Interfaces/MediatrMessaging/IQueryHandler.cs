﻿using MediatR;

namespace RazorCompany.Application.Interfaces.MediatrMessaging
{
    public interface IQueryHandler<in TQuery, TResponse> :
        IRequestHandler<TQuery, TResponse> where TQuery :
        IQuery<TResponse>
    {
    }
}