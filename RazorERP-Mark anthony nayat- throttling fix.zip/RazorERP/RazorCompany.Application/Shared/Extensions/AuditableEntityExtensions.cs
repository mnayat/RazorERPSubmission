﻿using RazorCompany.Domain.Entities.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RazorCompany.Application.Shared.Extensions
{
    public static class AuditableEntityExtensions
    {
        public static void SetAuditFieldsOnCreate(this BaseAuditableEntity entity, string createdBy)
        {
            entity.CreatedDate = DateTime.UtcNow;
            entity.CreatedBy = createdBy;
        }

        public static void SetAuditFieldsOnUpdate(this BaseAuditableEntity entity, string modifiedBy)
        {
            entity.ModifiedDate = DateTime.UtcNow;
            entity.ModifiedBy = modifiedBy;
        }

       
    }
}
