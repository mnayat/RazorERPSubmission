﻿using RazorCompany.Domain.Entities.Common;
using RazorCompany.Domain.Enums;

namespace RazorCompany.Domain.Entities
{
    public class RazorCompanyUser : BaseAuditableEntity
    {
        public int RazorERPUserID { get; set; }

        public string UserName { get; set; }
        public string PasswordHash { get; set; }
        public byte[] PasswordSalt { get; set; }
        public int CompanyID { get; set; }
        public virtual Company Company { get; set; }
        public UserRole UserRole { get; set; }
    }
}