﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RazorCompany.Infrastructure.ServiceCollection;

namespace RazorCompany.Infrastructure
{
    public static class InfrastructureServiceCollection
    {
        public static IServiceCollection AddInfrastructure(
            this IServiceCollection services,
            IConfiguration configuration)
        {
            services.AddDatabaseContext(configuration);
            services.AddAuthentication(configuration);
            services.AddRepositories();
            return services;
        }
    }
}