﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using RazorCompany.Application.Interfaces.JWTService;
using RazorCompany.Domain.Enums;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace RazorCompany.Infrastructure.JWTService
{
    public class JWTAuthService : IJWTAuthService
    {
        private readonly JWTConfig _jwtConfig;

        public JWTAuthService(IOptions<JWTConfig> jwtConfig)
        {
            _jwtConfig = jwtConfig.Value;
        }

        public string GenerateUserJwtToken(string username,UserRole role )
        {
            var secretKey =
                new SymmetricSecurityKey(
                    Encoding.UTF8.GetBytes(_jwtConfig.Secret)
                    );

            var signingCredentials =
                new SigningCredentials(
                    secretKey,
                    SecurityAlgorithms.HmacSha256);
            var claims = new List<Claim> {
                new Claim(JwtRegisteredClaimNames.Sub, username.Trim()),
                 new Claim( ClaimTypes.Name,  username.Trim()),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),

                new Claim(ClaimTypes.Role, role.ToString()),
            };
            // need to incorporate for the user roles in claim

            var securityToken = new JwtSecurityToken(
                  issuer: _jwtConfig.Issuer,
                  audience: _jwtConfig.Audience,
                  expires: DateTime.UtcNow.AddMinutes(_jwtConfig.ExpiryMinutes),
                  claims: claims,
                  signingCredentials: signingCredentials
                );

            return new JwtSecurityTokenHandler().WriteToken(securityToken);
        }
    }
}