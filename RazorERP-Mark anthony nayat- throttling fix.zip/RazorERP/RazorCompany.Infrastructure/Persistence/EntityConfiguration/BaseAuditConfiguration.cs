﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RazorCompany.Domain.Entities.Common;

namespace RazorCompany.Infrastructure.Persistence.EntityConfiguration
{
    public class BaseAuditConfiguration<TEntity> : IEntityTypeConfiguration<TEntity>
        where TEntity : BaseAuditableEntity
    {
        public void Configure(EntityTypeBuilder<TEntity> builder)
        {
            AuditConfiguration.ConfigureAuditFields(builder);
        }
    }
}