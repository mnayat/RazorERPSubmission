﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RazorCompany.Domain.Entities;
using RazorCompany.Domain.Enums;
using System.Data;

namespace RazorCompany.Infrastructure.Persistence.EntityConfiguration
{
    public class RazorERPUserConfiguration : IEntityTypeConfiguration<RazorCompanyUser>
    {
        public void Configure(EntityTypeBuilder<RazorCompanyUser> builder)
        {
            AuditConfiguration.ConfigureAuditFields(builder);

            builder.ToTable(nameof(RazorCompanyUser), "RazorERP");

            builder.HasKey(u => u.RazorERPUserID)
              .HasAnnotation("SqlServer:Identity", "1, 1");

            builder.Property(u => u.UserName)
           .HasMaxLength(200)
           .HasColumnType(DBDataType.NVARCHAR.ToString());

           
    
        }
    }
}