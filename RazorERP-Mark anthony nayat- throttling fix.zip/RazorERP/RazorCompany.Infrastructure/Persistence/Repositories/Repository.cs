﻿using Microsoft.EntityFrameworkCore;
using RazorCompany.Application.Interfaces.Persistence;
using RazorCompany.Domain.Entities.Common;
using System.Linq.Expressions;

namespace RazorCompany.Infrastructure.Persistence.Repositories
{
    public class Repository<T> : IRepository<T> where T : BaseAuditableEntity
    {
        private readonly ApplicationDBContext _dbContext;

        public Repository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<T> AddAsync(T entity)
        {
            await _dbContext.Set<T>().AddAsync(entity);
            return entity;
        }

        public async Task<bool> AnyAsync(Expression<Func<T, bool>> predicate)
        {
            var exist = _dbContext.Set<T>().Any(predicate);
            return await Task.FromResult(exist);
        }

        public Task DeleteAsync(T entity)
        {
            _dbContext.Set<T>().Remove(entity);
            return Task.CompletedTask;
        }

        public async Task<T> GetByIdAsync(int id)
        {
            var result = await _dbContext.Set<T>().FindAsync(id);
            return await Task.FromResult(result!);
        }

        public Task UpdateAsync(int id, T entity)
        {
            T? exist = _dbContext.Set<T>().Find(id);
            _dbContext.Entry(exist!).CurrentValues.SetValues(entity);
            return Task.CompletedTask;
        }
        public async Task<IQueryable<T>> GetAllAsync()
        {
            var entities = _dbContext.Set<T>().AsQueryable();
            return await Task.FromResult(entities);
        }
        public async Task<IQueryable<T>> ApplyPredicate(Expression<Func<T, bool>> predicate)
        {
            var query = _dbContext.Set<T>().Where(predicate).AsQueryable();

            return await Task.FromResult(query);
        }
    }
}