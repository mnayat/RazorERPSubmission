﻿using RazorCompany.Application.Interfaces.Persistence;
using RazorCompany.Domain.Entities.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RazorCompany.Infrastructure.Persistence.Repositories
{
    public class UnitofWork : IUnitofWork
    {
        private bool disposed;
        private Hashtable? repositories;
        private readonly ApplicationDBContext _dbContext;
        public UnitofWork(ApplicationDBContext dbContext)
        {

            _dbContext = dbContext;

        }
        public IRepository<T> GetRepository<T>() where T : BaseAuditableEntity
        {
            if (repositories == null)
                repositories = new Hashtable();

            var type = typeof(T).Name;

            if (!repositories.ContainsKey(type))
            {
                var repositoryType = typeof(Repository<>);

                var repositoryInstance = Activator.CreateInstance(repositoryType.MakeGenericType(typeof(T)), _dbContext);
                repositories.Add(type, repositoryInstance);
            }
            return (IRepository<T>)repositories[type]!;
        }

        public async Task<bool> SaveChanges(CancellationToken cancellationToken)
        {
            return await _dbContext.SaveChangesAsync(cancellationToken) >= 0 ? true : false;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    _dbContext.Dispose();
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}
