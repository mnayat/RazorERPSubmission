﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using RazorCompany.Application.Interfaces.JWTService;
using RazorCompany.Domain.Enums;
using RazorCompany.Infrastructure.JWTService;
using System.Text;

namespace RazorCompany.Infrastructure.ServiceCollection
{
    public static class AddJwtAuthentication
    {
        public static IServiceCollection AddAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            var jwtConfig = new JWTConfig();

            configuration.Bind(nameof(JWTConfig), jwtConfig);

            services.AddSingleton(Options.Create(jwtConfig));

            services.AddSingleton<IJWTAuthService, JWTAuthService>();

            services.AddAuthentication(option =>
            {
                option.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                option.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = jwtConfig.Issuer,
                        ValidAudience = jwtConfig.Audience,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtConfig.Secret))
                    };
                }

                );

            services.AddAuthorization(options =>
            {

                options.AddPolicy("Admin", policy => policy.RequireRole(UserRole.Admin.ToString()));
                options.AddPolicy("FlatUsers", policy => policy.RequireRole(UserRole.FlatUsers.ToString()));
            });

            return services;
        }
    }
}