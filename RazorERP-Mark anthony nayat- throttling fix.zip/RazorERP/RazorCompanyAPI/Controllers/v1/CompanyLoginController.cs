﻿using Asp.Versioning;
using Azure.Core;
using MapsterMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using RazorCompany.Application.Features.Authentication;

namespace RazorCompanyAPI.Controllers.v1
{
    [ApiController]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiVersion("1.0")]
    public class CompanyLoginController : ControllerBase
    {
        private readonly ISender _mediator;
        private readonly IMapper _mapper;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="mediator"></param>
        /// <param name="mapper"></param>
        public CompanyLoginController(ISender mediator, IMapper mapper)
        {
            _mediator = mediator;
            _mapper = mapper;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Login(LoginRequest request)
        {
            var authenticateQuery = _mapper.Map<LoginQuery>(request);
            var result = await _mediator.Send(authenticateQuery);
            if (result.IsSuccess)
                return Ok(result);
            return BadRequest(result);
        }
    }
}
