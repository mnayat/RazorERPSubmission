﻿using Asp.Versioning;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RazorCompany.Application.Features.CompanyUser.CreateCompanyUser;
using RazorCompany.Application.Features.CompanyUser.DeleteCompanyUser;
using RazorCompany.Application.Features.CompanyUser.PopulateCompanyUser;
using RazorCompany.Application.Features.CompanyUser.UpdateCompanyUser;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace RazorCompanyAPI.Controllers.v1
{
    [ApiController]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiVersion("1.0")]
    public class CompanyUserController : ControllerBase
    {
        private readonly ISender _mediator;
       /// <summary>
       /// 
       /// </summary>
       /// <param name="mediator"></param>
        public CompanyUserController(ISender mediator)
        {
            _mediator = mediator;
        }
        [Authorize(Policy = "FlatUsers")]
        [HttpGet]
        public async Task<IActionResult> GetAllCompanyUser()
        {
            var query = new PopulateCompanyUserQuery();
            var result = await _mediator.Send(query);

            return result.IsSuccess
                ? Ok(result)
                : BadRequest(result.Messages);

        }
        /// <summary>
        /// Create new company user
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [Authorize(Policy = "Admin")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> CreateCompanyUser([FromBody] CreateCompanyUserCommand command)
        {
            var result = await _mediator.Send(command);
            if (result.IsSuccess)
                return StatusCode(StatusCodes.Status201Created, result);

            return StatusCode(result.StatusCode, result.Messages);
        }
        [Authorize(Policy = "Admin")]
        [HttpPut]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> UpdateCompanyUser([FromBody] UpdateCompanyUserCommand updateCompanyUserCommand)
        {
            var result = await _mediator.Send(updateCompanyUserCommand);
            if (result.IsSuccess)
                return StatusCode(StatusCodes.Status200OK, result);

            return StatusCode(result.StatusCode, result.Messages);
        }

        [HttpDelete]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> DeleteCompanyUser(DeleteCompanyUserCommand deleteCompanyUserCommand)
        {
            var result = await _mediator.Send(deleteCompanyUserCommand);
            if (result.IsSuccess)
                return StatusCode(StatusCodes.Status200OK, result);

            return StatusCode(result.StatusCode, result.Messages);
        }
    }
}
