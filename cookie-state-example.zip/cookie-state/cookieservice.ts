import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';

@Injectable({ providedIn: 'root' })
export class AppStateService {
  private selectedItemSubject = new BehaviorSubject<string>('Default'); // Default dropdown value
  selectedItem$ = this.selectedItemSubject.asObservable();

  private permissionListSubject = new BehaviorSubject<string[]>([]); // Default empty permissions
  permissionList$ = this.permissionListSubject.asObservable();

  private usernameSubject = new BehaviorSubject<string>(''); // Default username
  username$ = this.usernameSubject.asObservable();

  // Permissions mapped to each dropdown item
  private permissionMap: { [key: string]: string[] } = {
    Admin: ['Read', 'Write', 'Execute'],
    User: ['Read', 'Write'],
    Manager: ['Read', 'Execute'],
    Default: ['Read'],
  };

  constructor(private cookieService: CookieService) {}

  // Initialize state from cookies
  initializeState() {
    const savedItem = this.cookieService.get('selectedItem') || 'Default';
    const savedUsername = this.cookieService.get('username') || '';

    this.selectedItemSubject.next(savedItem);
    this.permissionListSubject.next(this.permissionMap[savedItem] || []);
    this.usernameSubject.next(savedUsername);
  }

  // Update dropdown selection and derive permissions
  updateSelectedItem(item: string) {
    this.selectedItemSubject.next(item);
    this.permissionListSubject.next(this.permissionMap[item] || []);
    this.cookieService.set('selectedItem', item, { sameSite: 'Strict', expires: 7 });
  }

  // Save username to cookies
  updateUsername(username: string) {
    this.usernameSubject.next(username);
    this.cookieService.set('username', username, { sameSite: 'Strict', expires: 7 });
  }
}