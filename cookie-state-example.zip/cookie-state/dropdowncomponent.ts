import { Component, OnInit } from '@angular/core';
import { AppStateService } from './state.service';

@Component({
  selector: 'app-dropdown',
  standalone: true,
  template: `
    <select [(ngModel)]="selectedItem" (change)="onSelectionChange($event)">
      <option *ngFor="let item of items" [value]="item">{{ item }}</option>
    </select>
  `,
})
export class DropdownComponent implements OnInit {
  items = ['Admin', 'User', 'Manager'];
  selectedItem = 'Default';

  constructor(private appStateService: AppStateService) {}

  ngOnInit() {
    // Initialize state from the service
    this.appStateService.initializeState();
    this.appStateService.selectedItem$.subscribe((item) => {
      this.selectedItem = item;
    });
  }

  onSelectionChange(event: any) {
    const newItem = event.target.value;
    this.appStateService.updateSelectedItem(newItem); // Update selection and permissions
  }
}