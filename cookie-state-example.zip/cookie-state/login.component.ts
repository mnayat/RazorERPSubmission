import { Component } from '@angular/core';
import { AppStateService } from './state.service';

@Component({
  selector: 'app-login',
  standalone: true,
  template: `
    <input [(ngModel)]="username" placeholder="Enter username" />
    <input type="password" [(ngModel)]="password" placeholder="Enter password" />
    <button (click)="login()">Login</button>
  `,
})
export class LoginComponent {
  username = '';
  password = '';

  constructor(private appStateService: AppStateService) {}

  login() {
    this.appStateService.login(this.username, this.password);
  }
}