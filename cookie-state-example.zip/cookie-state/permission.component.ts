import { Component, OnInit } from '@angular/core';
import { AppStateService } from './state.service';

@Component({
  selector: 'app-permission-list',
  standalone: true,
  template: `
    <h3>Permission List</h3>
    <ul>
      <li *ngFor="let permission of permissions">{{ permission }}</li>
    </ul>
  `,
})
export class PermissionListComponent implements OnInit {
  permissions: string[] = [];

  constructor(private appStateService: AppStateService) {}

  ngOnInit() {
    // Subscribe to permission changes
    this.appStateService.permissionList$.subscribe((list) => {
      this.permissions = list;
    });
  }
}