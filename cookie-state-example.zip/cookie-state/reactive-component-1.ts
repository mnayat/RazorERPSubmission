import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { AppStateService } from './state.service';

@Component({
  selector: 'app-reactive-1',
  standalone: true,
  template: `<p>Selected Item: {{ selectedItem }}</p>`,
  changeDetection: ChangeDetectionStrategy.OnPush, // Optimize change detection
})
export class ReactiveComponent1 implements OnInit {
  selectedItem = '';

  constructor(private appStateService: AppStateService) {}

  ngOnInit() {
    // Subscribe to selectedItem changes
    this.appStateService.selectedItem$.subscribe((item) => {
      this.selectedItem = item;
    });
  }
}