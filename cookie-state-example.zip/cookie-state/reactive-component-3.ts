import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { AppStateService } from './state.service';

@Component({
  selector: 'app-reactive-3',
  standalone: true,
  template: `
    <h4>Permissions:</h4>
    <ul>
      <li *ngFor="let permission of permissions">{{ permission }}</li>
    </ul>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush, // Optimize change detection
})
export class ReactiveComponent3 implements OnInit {
  permissions: string[] = [];

  constructor(private appStateService: AppStateService) {}

  ngOnInit() {
    // Subscribe to permission list changes
    this.appStateService.permissionList$.subscribe((permissions) => {
      this.permissions = permissions;
    });
  }
}