import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { AppStateService } from './state.service';

@Component({
  selector: 'app-reactive-2',
  standalone: true,
  template: `<p>Permission Count: {{ permissionCount }}</p>`,
  changeDetection: ChangeDetectionStrategy.OnPush, // Optimize change detection
})
export class ReactiveComponent2 implements OnInit {
  permissionCount = 0;

  constructor(private appStateService: AppStateService) {}

  ngOnInit() {
    // Subscribe to permission list changes
    this.appStateService.permissionList$.subscribe((permissions) => {
      this.permissionCount = permissions.length;
    });
  }
}