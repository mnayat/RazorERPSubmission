import { Component, OnInit } from '@angular/core';
import { AppStateService } from './state.service';

@Component({
  selector: 'app-reactive',
  standalone: true,
  template: `<p>Reacting to Selected Item: {{ selectedItem }}</p>`,
})
export class ReactiveComponent implements OnInit {
  selectedItem = '';

  constructor(private appStateService: AppStateService) {}

  ngOnInit() {
    this.appStateService.selectedItem$.subscribe((item) => {
      this.selectedItem = item;
    });
  }
}