import { Component } from '@angular/core';
import { DropdownComponent } from './dropdown.component';
import { PermissionListComponent } from './permission-list.component';
import { AppStateService } from './state.service';

@Component({
  selector: 'app-root',
  standalone: true,
  template: `
    <app-dropdown></app-dropdown>
    <app-permission-list></app-permission-list>
  `,
  imports: [DropdownComponent, PermissionListComponent],
  providers: [AppStateService],
})
export class AppComponent {}