import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';

@Injectable({ providedIn: 'root' })
export class AppStateService {
  private selectedItemSubject = new BehaviorSubject<string>('Default'); // Default dropdown value
  selectedItem$ = this.selectedItemSubject.asObservable();

  private usernameSubject = new BehaviorSubject<string>(''); // Default username
  username$ = this.usernameSubject.asObservable();

  constructor(private http: HttpClient, private cookieService: CookieService) {}

  // Initialize state from cookies
  initializeState() {
    const savedItem = this.cookieService.get('selectedItem') || 'Default';
    const savedUsername = this.cookieService.get('username') || '';
    this.selectedItemSubject.next(savedItem);
    this.usernameSubject.next(savedUsername);
  }

  // Authenticate user and save token in a cookie
  login(username: string, password: string) {
    this.http.post<{ token: string }>('https://localhost:5001/auth/login', { username, password }).subscribe({
      next: (response) => {
        this.cookieService.set('authToken', response.token, { secure: true, sameSite: 'Strict', expires: 7 });
        this.usernameSubject.next(username);
        this.cookieService.set('username', username, { secure: true, sameSite: 'Strict', expires: 7 });
      },
      error: (error) => {
        console.error('Login failed:', error);
      },
    });
  }

  // Update dropdown selection and persist to cookies
  updateSelectedItem(item: string) {
    this.selectedItemSubject.next(item);
    this.cookieService.set('selectedItem', item, { sameSite: 'Strict', expires: 7 });
  }
}