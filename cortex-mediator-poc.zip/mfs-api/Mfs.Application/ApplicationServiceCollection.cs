﻿using Cortex.Mediator.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cortex.Mediator.Behaviors;
using Cortex.Mediator.Commands;
using Cortex.Mediator.Queries;
using Cortex.Mediator.Notifications;
using Cortex.Mediator;
using Mfs.Application.Behaviours;


namespace Mfs.Application
{
    public static class ApplicationServiceCollection
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services, IConfiguration configuration)
        {

           

            //services.AddScoped(typeof(ICommandPipelineBehavior<>), typeof(LoggingCommandBehavior<>));
            //services.AddScoped(typeof(ICommandPipelineBehavior<>), typeof(ValidationCommandBehavior<>));

            services.AddScoped(typeof(ICommandPipelineBehavior<>), typeof(ValidationCommandPipelineBehavior<>));

            services.AddScoped(typeof(IQueryPipelineBehavior<,>), typeof(ValidationQueryPipelineBehavior<,>));

            services.AddScoped<IMediator, Mediator>();
          
            services.AddCortexMediator(
                configuration,
                new[] { typeof(ApplicationServiceCollection)}
                );
           
            return services;
        }
       
    }
}
