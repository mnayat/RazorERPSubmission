﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cortex.Mediator.Commands;
using FluentValidation;
using FluentValidation.Results;

namespace Mfs.Application.Behaviours
{

    public class ValidationCommandPipelineBehavior<TCommand> : ICommandPipelineBehavior<TCommand>
        where TCommand : ICommand
    {
        private readonly IEnumerable<IValidator<TCommand>> _validators;

        public ValidationCommandPipelineBehavior(IEnumerable<IValidator<TCommand>> validators)
        {
            _validators = validators;
        }

       

        public async Task Handle(TCommand command, CommandHandlerDelegate next, CancellationToken cancellationToken)
        {
            if (!_validators.Any())
            {
                await next();
                return;
            }

            var context = new ValidationContext<TCommand>(command);
            var failures = _validators
                .Select(v => v.Validate(context))
                .SelectMany(r => r.Errors)
                .Where(e => e != null)
                .ToList();

            if (failures.Any())
            {
                var errorDict = failures
                    .GroupBy(f => f.PropertyName)
                    .ToDictionary(
                        g => g.Key,
                        g => g.Select(f => f.ErrorMessage).Distinct().ToArray()
                    );

                throw new ValidationException("Command validation failed", failures);
               
            }
            ////Result Pattern
            //if (failures.Any())
            //{
            //    var messages = failures.Select(f => $"{f.PropertyName}: {f.ErrorMessage}");
            //    var message = string.Join("; ", messages);

            //    // If your command has a Result property
            //    var resultProp = typeof(TCommand).GetProperty("Result");
            //    if (resultProp?.PropertyType == typeof(Result))
            //    {
            //        resultProp.SetValue(command, Result.Failure(message));
            //        return;
            //    }

            //    // Or just throw if Result isn't supported
            //    throw new ValidationException("Validation failed", failures);
            //}

            await next();
        }
    }
}
