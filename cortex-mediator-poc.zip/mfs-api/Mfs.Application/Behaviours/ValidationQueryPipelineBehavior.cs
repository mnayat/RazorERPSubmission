﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cortex.Mediator.Queries;
using FluentValidation;

namespace Mfs.Application.Behaviours
{
    public class ValidationQueryPipelineBehavior<TQuery, TResult> : IQueryPipelineBehavior<TQuery, TResult>
     where TQuery : IQuery<TResult>
    {
        private readonly IEnumerable<IValidator<TQuery>> _validators;

        public ValidationQueryPipelineBehavior(IEnumerable<IValidator<TQuery>> validators)
        {
            _validators = validators;
        }

       

        public async Task<TResult> Handle(TQuery query, QueryHandlerDelegate<TResult> next, CancellationToken cancellationToken)
        {
            if (!_validators.Any())
                return await next();

            var context = new ValidationContext<TQuery>(query);
            var failures = _validators
                .Select(v => v.Validate(context))
                .SelectMany(r => r.Errors)
                .Where(e => e != null)
                .ToList();

            if (failures.Any())
            {
                throw new ValidationException("Query validation failed", failures);
            }
            ////Result Pattern

            //if (failures.Any())
            //{
            //    var errorMessages = failures
            //        .Select(f => $"{f.PropertyName}: {f.ErrorMessage}")
            //        .ToArray();

            //    return Result<TResult>.Failure(errorMessages);
            //}

            return await next();
        }
    }
}
