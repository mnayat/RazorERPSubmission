﻿namespace Mfs.Application
{
    public class Class1
    {

    }
}
