﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cortex.Mediator;
using Cortex.Mediator.Commands;

namespace Mfs.Application.CortexMessaging
{
    public interface ICommand<TResponse>
    {
    }


}
