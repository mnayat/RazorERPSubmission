﻿using Cortex.Mediator.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mfs.Application.Person.GetUserByIdQuery
{
    public class GetUserByIdQueryHandler : IQueryHandler<GetUserByIdQuery, string>
    {
        public async Task<string> Handle(GetUserByIdQuery query, CancellationToken cancellationToken)
        {
           
            var user = await Task.FromResult($"User with ID: {query.PersonID}");
            return user;
        }
    }
}
