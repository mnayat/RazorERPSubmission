﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mfs.Application.Person.GetUserByIdQuery
{
    public class GetUserByIdValidator : AbstractValidator<GetUserByIdQuery>
    {
        public GetUserByIdValidator()
        {
            RuleFor(x => x.PersonID).GreaterThan(0).WithMessage("User ID must be positive.");
        }
    }
    
}
