﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cortex.Mediator;
using Cortex.Mediator.Commands;
using Cortex.Mediator.Queries;


namespace Mfs.Application.Person
{
    public class PersonCommandHandler : ICommandHandler<PersonCommand>
    {
        public async Task Handle(PersonCommand command, CancellationToken cancellationToken)
        {
            command = command with { Name = command.Name };
             await Task.CompletedTask;
            
        }
    }
}
