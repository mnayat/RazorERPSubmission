﻿namespace Mfs.Domain
{
    public class Class1
    {

    }
}
