﻿namespace Mfs.Infrastructure
{
    public class Class1
    {

    }
}
