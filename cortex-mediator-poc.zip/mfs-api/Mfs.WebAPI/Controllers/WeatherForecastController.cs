using Cortex.Mediator;
using Cortex.Mediator.Exceptions;
using Mfs.Application.Person;
using Mfs.Application.Person.GetUserByIdQuery;

using Microsoft.AspNetCore.Mvc;

namespace Mfs.WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IMediator _mediator;
       
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

      

        public WeatherForecastController(ILogger<WeatherForecastController> logger, IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public IEnumerable<WeatherForecast> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }

        [HttpPost(Name ="Insert")]
        public async Task<IActionResult> UpdateUser(PersonCommand command)
        {
            try
            {
                await _mediator.SendAsync(command);
                return Ok(command.Name);

            }
            catch (ValidationException ex)
            {
                return BadRequest(new
                {
                    Message = "Validation failed",
                    Errors = ex.Errors.Select(e => new { e.Key, e.Value })
                });
            }
            

        }

        [HttpPost("getPerson")]
        public async Task<IActionResult> GetUser(GetUserByIdQuery? id)
        {
            try
            {
            var result = await _mediator.SendAsync<GetUserByIdQuery, string>(id);

            return Ok(result);

            }
            catch (ValidationException ex)
            {
                return BadRequest(new
                {
                    Message = "Validation failed",
                    Errors = ex.Errors.Select(e => new { e.Key, e.Value })
                });
            }
        }
    }
}
